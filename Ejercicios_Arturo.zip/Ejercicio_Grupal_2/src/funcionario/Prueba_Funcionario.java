package funcionario;

public class Prueba_Funcionario {

	public static void main(String[] args) {
		
		Funcionario func1 = new Funcionario("012345678-K","Arturo","Muñoz","Escribano","Madrid","21/10/2001",23500.43d);
		func1.getAtributos();

	}

}
